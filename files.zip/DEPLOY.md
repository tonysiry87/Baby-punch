# 🚀 Baby Punch — GitHub Pages Deployment Guide

## Quick Deploy (5 minutes)

### Step 1: Create a GitHub Repository
1. Go to https://github.com/new
2. Name it `babypunch` (or `babypunch-coin`)
3. Set it to **Public**
4. Click **Create repository**

### Step 2: Upload Your Files
Upload these files to the repo root:
- `index.html` ← the website
- `Baby_puch2.png` ← the monkey image (exact filename!)

### Step 3: Enable GitHub Pages
1. Go to your repo → **Settings** → **Pages**
2. Under **Source**, select `Deploy from a branch`
3. Choose branch: `main`, folder: `/ (root)`
4. Click **Save**

### Step 4: Your Site is Live! 🎉
Your URL will be:
`https://YOUR-USERNAME.github.io/babypunch/`

---

## Custom Domain (Optional)
1. Buy a domain (e.g. `babypunch.xyz` on Namecheap ~$10/yr)
2. In GitHub Pages settings, add your custom domain
3. Set DNS A records to GitHub's IPs:
   - 185.199.108.153
   - 185.199.109.153
   - 185.199.110.153
   - 185.199.111.153

---

## Update Social Links
In `index.html`, search for `href="#"` on the social buttons and replace with your real links:
- Twitter: `https://twitter.com/BabyPunchCoin`
- Telegram: `https://t.me/BabyPunchOfficial`
- Discord: `https://discord.gg/YOURLINK`
- Dextools: `https://www.dextools.io/app/ether/pair-explorer/YOUR-PAIR`
- Uniswap: `https://app.uniswap.org/swap?outputCurrency=YOUR-CONTRACT`
- CoinMarketCap: Your CMC link after listing

## Update Contract Address
Search for `0x000...BPUNCH` and replace with your real contract address.
